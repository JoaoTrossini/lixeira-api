#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>

// ==========================================
// PINOS
// ==========================================

// Sensor externo
const int TRIG_EXTERNO = 4;
const int ECHO_EXTERNO = 5;

// Servo
const int SERVO = 6;

// LEDs
const int LED_VERDE = 7;
const int LED_VERMELHO = 8;

// Sensor interno
const int TRIG_INTERNO = 9;
const int ECHO_INTERNO = 10;

// ==========================================
// WIFI
// ==========================================

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// API
const char* apiUrl =
    "https://lixeira-api.onrender.com/api/leituras";

WebServer server(80);

// ==========================================
// VARIÁVEIS
// ==========================================

bool tampaAberta = false;
bool coletaSolicitada = false;

float distanciaExterna = 0;
float distanciaInterna = 30;

int nivelLixeira = 0;

// ==========================================
// CONFIGURAÇÕES
// ==========================================

// Altura interna da lixeira
const float ALTURA_LIXEIRA = 30.0;

// Coleta somente a partir de 60%
const int LIMITE_COLETA = 60;

// Distância para detectar uma pessoa/mão
const float DISTANCIA_ABRIR = 20.0;

// Para fechar, precisa ficar acima desse valor
const float DISTANCIA_FECHAR = 25.0;

// Número de medições para confirmar presença
const int LEITURAS_PRESENCA = 3;

// Número de medições para confirmar ausência
const int LEITURAS_AUSENCIA = 4;

// Intervalo entre leituras do sensor
const int INTERVALO_SENSOR = 80;

// Envio periódico para API
unsigned long ultimoEnvioAPI = 0;

const unsigned long INTERVALO_API = 10000;

// ==========================================
// CONTROLE DE ESTABILIDADE
// ==========================================

int contadorPresenca = 0;
int contadorAusencia = 0;

// ==========================================
// SERVO
// ==========================================

void moverServo(int angulo) {

  int pulso = map(
      angulo,
      0,
      180,
      500,
      2400
  );

  for (int i = 0; i < 40; i++) {

    digitalWrite(SERVO, HIGH);

    delayMicroseconds(pulso);

    digitalWrite(SERVO, LOW);

    delayMicroseconds(20000 - pulso);
  }
}

// ==========================================
// MEDIR DISTÂNCIA
// ==========================================

float medirDistancia(int trig, int echo) {

  digitalWrite(trig, LOW);

  delayMicroseconds(2);

  digitalWrite(trig, HIGH);

  delayMicroseconds(10);

  digitalWrite(trig, LOW);

  long duracao = pulseIn(
      echo,
      HIGH,
      30000
  );

  if (duracao == 0) {

    return -1;
  }

  float distancia =
      duracao * 0.0343 / 2;

  // Ignora valores impossíveis
  if (
      distancia < 2 ||
      distancia > 400
  ) {

    return -1;
  }

  return distancia;
}

// ==========================================
// MEDIR SENSOR INTERNO COM FILTRO
// ==========================================

float medirDistanciaInternaFiltrada() {

  float soma = 0;

  int leiturasValidas = 0;

  const int TOTAL_LEITURAS = 5;

  for (
      int i = 0;
      i < TOTAL_LEITURAS;
      i++
  ) {

    float leitura =
        medirDistancia(
            TRIG_INTERNO,
            ECHO_INTERNO
        );

    if (leitura > 0) {

      soma += leitura;

      leiturasValidas++;
    }

    delay(40);
  }

  // Se não conseguiu medir
  if (leiturasValidas == 0) {

    return -1;
  }

  return soma / leiturasValidas;
}

// ==========================================
// ATUALIZAR LEDS
// ==========================================

void atualizarLeds() {

  if (
      nivelLixeira >= LIMITE_COLETA
  ) {

    digitalWrite(
        LED_VERDE,
        LOW
    );

    digitalWrite(
        LED_VERMELHO,
        HIGH
    );

  } else {

    digitalWrite(
        LED_VERDE,
        HIGH
    );

    digitalWrite(
        LED_VERMELHO,
        LOW
    );
  }
}

// ==========================================
// CALCULAR NÍVEL
// ==========================================

void calcularNivel() {

  float novaDistancia =
      medirDistanciaInternaFiltrada();

  // Se a leitura falhou,
  // mantém o último valor
  if (novaDistancia <= 0) {

    return;
  }

  // ========================================
  // LIMITAR DISTÂNCIA
  // ========================================

  if (
      novaDistancia > ALTURA_LIXEIRA
  ) {

    novaDistancia =
        ALTURA_LIXEIRA;
  }

  if (novaDistancia < 2) {

    novaDistancia = 2;
  }

  distanciaInterna =
      novaDistancia;

  // ========================================
  // CALCULAR NÍVEL
  // ========================================

  float nivelCalculado =
      (
          (ALTURA_LIXEIRA - distanciaInterna)
          / ALTURA_LIXEIRA
      ) * 100;

  // ========================================
  // LIMITAR 0-100
  // ========================================

  if (nivelCalculado < 0) {

    nivelCalculado = 0;
  }

  if (nivelCalculado > 100) {

    nivelCalculado = 100;
  }

  nivelLixeira =
      (int)nivelCalculado;

  // ========================================
  // COLETA
  // ========================================

  if (
      nivelLixeira >= LIMITE_COLETA
  ) {

    coletaSolicitada = true;

  } else {

    coletaSolicitada = false;
  }

  // ========================================
  // LEDS
  // ========================================

  atualizarLeds();
}

// ==========================================
// ENVIAR LEITURA PARA API
// ==========================================

void enviarLeituraAPI() {

  if (
      WiFi.status() != WL_CONNECTED
  ) {

    Serial.println(
        "Wi-Fi desconectado."
    );

    WiFi.disconnect();

    WiFi.begin(
        ssid,
        password
    );

    unsigned long inicio =
        millis();

    while (
        WiFi.status() != WL_CONNECTED &&
        millis() - inicio < 10000
    ) {

      delay(500);

      Serial.print(".");
    }

    Serial.println();

    if (
        WiFi.status() != WL_CONNECTED
    ) {

      Serial.println(
          "Não foi possível reconectar."
      );

      return;
    }
  }

  // ========================================
  // HTTPS
  // ========================================

  WiFiClientSecure client;

  client.setInsecure();

  HTTPClient http;

  Serial.println(
      "=============================="
  );

  Serial.println(
      "Enviando leitura para API..."
  );

  if (
      !http.begin(
          client,
          apiUrl
      )
  ) {

    Serial.println(
        "Erro ao iniciar HTTPS."
    );

    return;
  }

  http.setTimeout(15000);

  http.addHeader(
      "Content-Type",
      "application/json"
  );

  // ========================================
  // JSON
  // ========================================

  String json = "{";

  json += "\"nivel\":";
  json += String(
      nivelLixeira
  );

  json += ",";

  json += "\"distanciaInterna\":";
  json += String(
      distanciaInterna,
      1
  );

  json += ",";

  json += "\"distanciaExterna\":";
  json += String(
      distanciaExterna,
      1
  );

  json += ",";

  json += "\"tampa\":\"";

  if (tampaAberta) {

    json += "ABERTA";

  } else {

    json += "FECHADA";
  }

  json += "\"";

  json += ",";

  json += "\"coletaSolicitada\":";

  if (coletaSolicitada) {

    json += "true";

  } else {

    json += "false";
  }

  json += "}";

  Serial.println(
      "JSON enviado:"
  );

  Serial.println(json);

  // ========================================
  // POST
  // ========================================

  int codigoHTTP =
      http.POST(json);

  if (codigoHTTP > 0) {

    Serial.print(
        "Código HTTP: "
    );

    Serial.println(
        codigoHTTP
    );

    String resposta =
        http.getString();

    Serial.println(
        "Resposta da API:"
    );

    Serial.println(
        resposta
    );

  } else {

    Serial.print(
        "Erro ao enviar para API: "
    );

    Serial.println(
        codigoHTTP
    );

    Serial.print(
        "Descrição: "
    );

    Serial.println(
        http.errorToString(
            codigoHTTP
        ).c_str()
    );
  }

  http.end();

  Serial.println(
      "=============================="
  );
}

// ==========================================
// PÁGINA WEB
// ==========================================

void paginaWeb() {

  String statusTampa;

  if (tampaAberta) {

    statusTampa = "ABERTA";

  } else {

    statusTampa = "FECHADA";
  }

  String statusColeta;

  if (coletaSolicitada) {

    statusColeta =
        "🚛 COLETA SOLICITADA";

  } else {

    statusColeta =
        "✅ Lixeira funcionando normalmente";
  }

  String html = "";

  html += "<!DOCTYPE html>";

  html += "<html>";

  html += "<head>";

  html += "<meta charset='UTF-8'>";

  html += "<meta name='viewport' ";
  html += "content='width=device-width, initial-scale=1'>";

  html += "<meta http-equiv='refresh' content='2'>";

  html += "<title>Lixeira Inteligente</title>";

  // ========================================
  // CSS
  // ========================================

  html += "<style>";

  html += "body{";
  html += "font-family:Arial;";
  html += "background:#f2f2f2;";
  html += "text-align:center;";
  html += "padding:30px;";
  html += "}";

  html += ".card{";
  html += "max-width:450px;";
  html += "margin:auto;";
  html += "background:white;";
  html += "padding:30px;";
  html += "border-radius:20px;";
  html += "box-shadow:0 4px 15px rgba(0,0,0,.15);";
  html += "}";

  html += "h1{";
  html += "color:#333;";
  html += "}";

  html += ".nivel{";
  html += "font-size:40px;";
  html += "font-weight:bold;";
  html += "margin:20px;";
  html += "}";

  html += ".barra{";
  html += "width:100%;";
  html += "height:30px;";
  html += "background:#ddd;";
  html += "border-radius:15px;";
  html += "overflow:hidden;";
  html += "}";

  html += ".progresso{";
  html += "height:100%;";
  html += "width:";
  html += String(nivelLixeira);
  html += "%;";
  html += "background:#4caf50;";
  html += "}";

  html += ".alerta{";
  html += "font-size:22px;";
  html += "font-weight:bold;";
  html += "margin:20px;";
  html += "}";

  html += "</style>";

  html += "</head>";

  // ========================================
  // BODY
  // ========================================

  html += "<body>";

  html += "<div class='card'>";

  html += "<h1>🗑️ Lixeira Inteligente</h1>";

  html += "<h2>Tampa: ";

  html += statusTampa;

  html += "</h2>";

  html += "<p>Nível da lixeira</p>";

  html += "<div class='barra'>";

  html += "<div class='progresso'></div>";

  html += "</div>";

  html += "<div class='nivel'>";

  html += String(
      nivelLixeira
  );

  html += "%";

  html += "</div>";

  html += "<p>Distância interna: ";

  html += String(
      distanciaInterna,
      1
  );

  html += " cm</p>";

  html += "<div class='alerta'>";

  html += statusColeta;

  html += "</div>";

  html += "</div>";

  html += "</body>";

  html += "</html>";

  server.send(
      200,
      "text/html",
      html
  );
}

// ==========================================
// SETUP
// ==========================================

void setup() {

  Serial.begin(115200);

  // ========================================
  // SENSORES
  // ========================================

  pinMode(
      TRIG_EXTERNO,
      OUTPUT
  );

  pinMode(
      ECHO_EXTERNO,
      INPUT
  );

  pinMode(
      TRIG_INTERNO,
      OUTPUT
  );

  pinMode(
      ECHO_INTERNO,
      INPUT
  );

  // ========================================
  // SERVO
  // ========================================

  pinMode(
      SERVO,
      OUTPUT
  );

  digitalWrite(
      SERVO,
      LOW
  );

  // ========================================
  // LEDS
  // ========================================

  pinMode(
      LED_VERDE,
      OUTPUT
  );

  pinMode(
      LED_VERMELHO,
      OUTPUT
  );

  digitalWrite(
      LED_VERDE,
      HIGH
  );

  digitalWrite(
      LED_VERMELHO,
      LOW
  );

  // ========================================
  // WIFI
  // ========================================

  Serial.println();

  Serial.println(
      "=============================="
  );

  Serial.println(
      "     LIXEIRA INTELIGENTE"
  );

  Serial.println(
      "=============================="
  );

  Serial.println(
      "Conectando ao Wi-Fi..."
  );

  WiFi.mode(WIFI_STA);

  WiFi.begin(
      ssid,
      password
  );

  while (
      WiFi.status() != WL_CONNECTED
  ) {

    delay(500);

    Serial.print(".");
  }

  Serial.println();

  Serial.println(
      "Wi-Fi conectado!"
  );

  Serial.print(
      "IP da lixeira: "
  );

  Serial.println(
      WiFi.localIP()
  );

  // ========================================
  // SERVIDOR WEB
  // ========================================

  server.on(
      "/",
      paginaWeb
  );

  server.begin();

  Serial.println(
      "Servidor web iniciado!"
  );

  Serial.println(
      "=============================="
  );

  Serial.println(
      "API configurada:"
  );

  Serial.println(
      apiUrl
  );

  Serial.println(
      "=============================="
  );

  // ========================================
  // ESTADO INICIAL
  // ========================================

  tampaAberta = false;

  coletaSolicitada = false;

  distanciaInterna = ALTURA_LIXEIRA;

  nivelLixeira = 0;

  atualizarLeds();
}

// ==========================================
// LOOP
// ==========================================

void loop() {

  // ========================================
  // SERVIDOR WEB
  // ========================================

  server.handleClient();

  // ========================================
  // SENSOR EXTERNO
  // ========================================

  float novaDistanciaExterna =
      medirDistancia(
          TRIG_EXTERNO,
          ECHO_EXTERNO
      );

  // ========================================
  // DETECTAR PRESENÇA
  // ========================================

  if (
      novaDistanciaExterna > 0 &&
      novaDistanciaExterna <= DISTANCIA_ABRIR
  ) {

    contadorPresenca++;

    contadorAusencia = 0;

  } else {

    contadorPresenca = 0;

    if (
        novaDistanciaExterna >
            DISTANCIA_FECHAR
    ) {

      contadorAusencia++;

    } else {

      contadorAusencia = 0;
    }
  }

  // ========================================
  // ABRIR TAMPA
  // ========================================

  if (
      !tampaAberta &&
      contadorPresenca >= LEITURAS_PRESENCA
  ) {

    Serial.println();
    Serial.println(
        "Pessoa detectada."
    );

    Serial.println(
        "Abrindo tampa..."
    );

    moverServo(90);

    tampaAberta = true;

    contadorPresenca = 0;
    contadorAusencia = 0;

    Serial.println(
        "Tampa: ABERTA"
    );

    // Atualiza nível
    calcularNivel();

    // Envia estado da tampa
    enviarLeituraAPI();

    ultimoEnvioAPI = millis();

    // Pequena pausa para estabilizar
    delay(500);
  }

  // ========================================
  // FECHAR TAMPA
  // ========================================

  if (
      tampaAberta &&
      contadorAusencia >= LEITURAS_AUSENCIA
  ) {

    Serial.println();

    Serial.println(
        "Pessoa saiu."
    );

    Serial.println(
        "Fechando tampa..."
    );

    moverServo(0);

    tampaAberta = false;

    contadorPresenca = 0;
    contadorAusencia = 0;

    Serial.println(
        "Tampa: FECHADA"
    );

    // Atualiza nível
    calcularNivel();

    // Envia estado da tampa
    enviarLeituraAPI();

    ultimoEnvioAPI = millis();

    delay(500);
  }

  // ========================================
  // ATUALIZAR DISTÂNCIA EXTERNA
  // ========================================

  if (
      novaDistanciaExterna > 0
  ) {

    distanciaExterna =
        novaDistanciaExterna;
  }

  // ========================================
  // MEDIR NÍVEL
  // ========================================

  calcularNivel();

  // ========================================
  // MONITOR SERIAL
  // ========================================

  Serial.print(
      "Distancia externa: "
  );

  Serial.print(
      distanciaExterna,
      1
  );

  Serial.println(
      " cm"
  );

  Serial.print(
      "Distancia interna: "
  );

  Serial.print(
      distanciaInterna,
      1
  );

  Serial.println(
      " cm"
  );

  Serial.print(
      "Nivel da lixeira: "
  );

  Serial.print(
      nivelLixeira
  );

  Serial.println(
      "%"
  );

  Serial.print(
      "Tampa: "
  );

  if (tampaAberta) {

    Serial.println(
        "ABERTA"
    );

  } else {

    Serial.println(
        "FECHADA"
    );
  }

  if (coletaSolicitada) {

    Serial.println(
        "Status: COLETA SOLICITADA"
    );

  } else {

    Serial.println(
        "Status: NORMAL"
    );
  }

  Serial.println();

  // ========================================
  // ENVIO PERIÓDICO
  // ========================================

  if (
      millis() - ultimoEnvioAPI >=
      INTERVALO_API
  ) {

    enviarLeituraAPI();

    ultimoEnvioAPI =
        millis();
  }

  // ========================================
  // PEQUENA PAUSA
  // ========================================

  delay(300);
}